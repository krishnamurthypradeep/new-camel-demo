package org.mycompany;

import java.time.LocalDate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;



// <orders><orderId>1233</orderId><orderName>djdhjdh</orderName><orderDate>2019-09-24</orderDate></orders>

@XmlRootElement(name="orders")
@XmlAccessorType(XmlAccessType.FIELD)
public class Orders {
	
	
	private int orderId;
	
	private String orderName;
	
	@XmlJavaTypeAdapter(value=LocalDateConverter.class)
	private LocalDate orderDate;
	
	public Orders() {
		// TODO Auto-generated constructor stub
	}

	public Orders(int orderId, String orderName, LocalDate orderDate) {
		this.orderId = orderId;
		this.orderName = orderName;
		this.orderDate = orderDate;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	
	
	

}
