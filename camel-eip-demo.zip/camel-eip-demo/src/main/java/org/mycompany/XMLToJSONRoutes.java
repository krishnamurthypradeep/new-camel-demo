package org.mycompany;

import javax.xml.bind.JAXBContext;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.converter.jaxb.JaxbDataFormat;
import org.springframework.stereotype.Component;

@Component
public class XMLToJSONRoutes extends RouteBuilder{

	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
		
		JaxbDataFormat xmlDataFormat = new JaxbDataFormat();
		JAXBContext jaxbContext = JAXBContext.newInstance(Orders.class);
		xmlDataFormat.setContext(jaxbContext);
		JacksonDataFormat jsonDataFormat = new JacksonDataFormat(Orders.class);
		from("file:input/neworders?noop=true").unmarshal(xmlDataFormat).marshal(jsonDataFormat).to("file:output/jsonorders");
		
	}

}
